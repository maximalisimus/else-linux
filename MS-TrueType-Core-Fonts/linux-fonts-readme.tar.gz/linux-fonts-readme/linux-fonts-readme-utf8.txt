﻿
/usr/share/fonts/truetype/
fc-cache –fv

